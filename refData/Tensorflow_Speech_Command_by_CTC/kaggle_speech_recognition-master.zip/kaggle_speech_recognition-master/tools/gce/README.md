Scripts for Google Cloud Engine.
Tested on OS X 10.11 El Capitan.